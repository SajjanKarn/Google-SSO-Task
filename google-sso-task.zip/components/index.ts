import SafeAreaWrapper from "./SafeAreaWrapper.component";

export { SafeAreaWrapper };
